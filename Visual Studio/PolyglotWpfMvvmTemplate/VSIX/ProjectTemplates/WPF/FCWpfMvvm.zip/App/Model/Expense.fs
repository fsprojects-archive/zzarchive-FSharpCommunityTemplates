﻿namespace FSharpWpfMvvmTemplate.Model

type Expense =
    { ExpenseType : string
      ExpenseAmount : string}
