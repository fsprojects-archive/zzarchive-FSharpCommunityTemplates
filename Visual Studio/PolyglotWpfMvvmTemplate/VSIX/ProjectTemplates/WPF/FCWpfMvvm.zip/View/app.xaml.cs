﻿using FSharpWpfMvvmTemplate;

namespace WpfMvvmTemplate.View
{
    public partial class App
    {
        static App()
        {
        }
    }
}
