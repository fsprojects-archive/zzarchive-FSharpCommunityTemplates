﻿using System.Windows;

namespace WpfMvvmTemplate.View
{
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
